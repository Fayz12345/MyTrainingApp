import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../bloc/auth/auth_bloc.dart';
import '../bloc/course/course_bloc.dart';
import '../models/course_model.dart';
import '../services/auth_service.dart';
import '../theme/app_theme.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (context) => CourseBloc()..add(const LoadCourses()),
      child: const ProfileScreenContent(),
    );
  }
}

class ProfileScreenContent extends StatefulWidget {
  const ProfileScreenContent({super.key});

  @override
  State<ProfileScreenContent> createState() => _ProfileScreenContentState();
}

class _ProfileScreenContentState extends State<ProfileScreenContent> {
  String? _userEmail;
  String? _userName;
  bool _isLoadingUserData = true;

  @override
  void initState() {
    super.initState();
    _loadUserData();
  }

  Future<void> _loadUserData() async {
    try {
      final email = await AuthService.getCurrentUserEmail();
      final username = await AuthService.getCurrentUsername();
      setState(() {
        _userEmail = email;
        _userName = username;
        _isLoadingUserData = false;
      });
    } catch (e) {
      setState(() {
        _isLoadingUserData = false;
      });
    }
  }

  String _getDisplayName(String? username) {
    if (username == null || username.isEmpty) return 'User';
    // Extract name from email or username
    if (username.contains('@')) {
      final namePart = username.split('@')[0];
      // Capitalize first letter of each word
      return namePart
          .split('.')
          .map((word) => word.isEmpty
              ? ''
              : word[0].toUpperCase() + word.substring(1).toLowerCase())
          .join(' ');
    }
    return username;
  }

  int _getCompletedCoursesCount(List<Course> courses) {
    return courses
        .where((course) => course.assignmentStatus == 'completed')
        .length;
  }

  int _getCertificatesCount(List<Course> courses) {
    // Certificates = completed courses that passed (assuming passing means certificate)
    return courses
        .where((course) => course.assignmentStatus == 'completed')
        .length; // For now, all completed courses count as certificates
  }

  List<Course> _getInProgressCourses(List<Course> courses) {
    return courses
        .where((course) =>
            course.assignmentStatus != 'completed' &&
            course.assignmentStatus != null)
        .toList();
  }

  double _calculateCourseProgress(Course course) {
    // For now, return a placeholder progress
    // In the future, you can calculate based on:
    // - Video watched percentage
    // - Quiz attempts
    // - Assignment status
    if (course.assignmentStatus == 'completed') {
      return 100.0;
    }
    // Placeholder: return random progress for demo
    // You can enhance this by tracking actual progress
    return 40.0;
  }

  @override
  Widget build(BuildContext context) {
    final dims = AppTheme.getDimensions(context);
    final isTablet = dims.isTablet;

    return BlocBuilder<AuthBloc, AuthState>(
      builder: (context, authState) {
        String? username;
        if (authState is AuthAuthenticated) {
          username = authState.username;
        }

        return BlocBuilder<CourseBloc, CourseState>(
          builder: (context, courseState) {
            List<Course> courses = [];
            if (courseState is CourseLoaded) {
              courses = courseState.courses;
            }

            final completedCount = _getCompletedCoursesCount(courses);
            final certificatesCount = _getCertificatesCount(courses);
            final inProgressCourses = _getInProgressCourses(courses);
            final displayName = _getDisplayName(_userName ?? username);

            return Scaffold(
              backgroundColor: Colors.grey[100],
              appBar: AppBar(
                title: const Text(
                  'Profile',
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                    color: Colors.black87,
                  ),
                ),
                backgroundColor: Colors.white,
                elevation: 0,
                actions: [
                  IconButton(
                    icon: const Icon(
                      Icons.edit,
                      color: AppTheme.primaryColor,
                    ),
                    onPressed: () {
                      // TODO: Implement edit profile
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(
                          content: Text('Edit profile coming soon'),
                        ),
                      );
                    },
                  ),
                ],
              ),
              body: _isLoadingUserData
                  ? const Center(child: CircularProgressIndicator())
                  : SingleChildScrollView(
                      child: Padding(
                        padding: EdgeInsets.all(isTablet ? 24.0 : 16.0),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.stretch,
                          children: [
                            // User Profile Card
                            _buildProfileCard(context, displayName, dims),
                            const SizedBox(height: 16),
                            // Learning Achievements Card
                            _buildAchievementsCard(context, completedCount,
                                certificatesCount, dims),
                            const SizedBox(height: 16),
                            // Current Progress Card
                            if (inProgressCourses.isNotEmpty)
                              _buildProgressCard(
                                  context, inProgressCourses, dims),
                            if (inProgressCourses.isNotEmpty)
                              const SizedBox(height: 16),
                            // Contact Information Card
                            _buildContactCard(context, dims),
                            const SizedBox(height: 16),
                            // Settings Card
                            _buildSettingsCard(context, dims),
                            SizedBox(height: isTablet ? 40 : 20),
                          ],
                        ),
                      ),
                    ),
            );
          },
        );
      },
    );
  }

  Widget _buildProfileCard(
      BuildContext context, String displayName, ResponsiveDimensions dims) {
    return Container(
      padding: EdgeInsets.all(dims.isTablet ? 24 : 20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
      ),
      child: Column(
        children: [
          // Profile Picture
          Container(
            width: dims.isTablet ? 100 : 80,
            height: dims.isTablet ? 100 : 80,
            decoration: BoxDecoration(
              color: Colors.orange[200],
              shape: BoxShape.circle,
            ),
            child: Icon(
              Icons.person,
              size: dims.isTablet ? 50 : 40,
              color: Colors.orange[700],
            ),
          ),
          const SizedBox(height: 16),
          // Name
          Align(
            alignment: AlignmentGeometry.center,
            child: Text(
              displayName,
              style: TextStyle(
                fontSize: (dims.isTablet ? 24 : 20) * dims.textScaleFactor,
                fontWeight: FontWeight.bold,
                color: Colors.black87,
              ),
            ),
          ),
          const SizedBox(height: 4),
          // Title/Position
          Text(
            'Employee',
            style: TextStyle(
              fontSize: (dims.isTablet ? 16 : 14) * dims.textScaleFactor,
              color: Colors.grey[600],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildAchievementsCard(BuildContext context, int completedCount,
      int certificatesCount, ResponsiveDimensions dims) {
    return Container(
      padding: EdgeInsets.all(dims.isTablet ? 24 : 12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          // Top Section - Courses Completed
          Card(
            color: Colors.white,
            elevation: 0,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
              side: BorderSide(color: Colors.grey[300]!, width: 1),
            ),
            child: Padding(
              padding: EdgeInsets.symmetric(
                vertical: dims.isTablet ? 15 : 10,
                horizontal: dims.isTablet ? 8 : 5,
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    '$completedCount',
                    style: TextStyle(
                      fontSize:
                          (dims.isTablet ? 36 : 30) * dims.textScaleFactor,
                      fontWeight: FontWeight.bold,
                      color: AppTheme.primaryColor,
                      height: 1.1,
                      letterSpacing: -1,
                    ),
                  ),
                  SizedBox(height: dims.isTablet ? 12 : 8),
                  Text(
                    'Courses Completed',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize:
                          (dims.isTablet ? 16 : 14) * dims.textScaleFactor,
                      color: Colors.grey[700],
                      height: 1.3,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ],
              ),
            ),
          ),
          SizedBox(height: dims.isTablet ? 16 : 8),
          // Bottom Section - Certificates Earned
          Card(
            color: Colors.white,
            elevation: 0,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
              side: BorderSide(color: Colors.grey[300]!, width: 1),
            ),
            child: Padding(
              padding: EdgeInsets.symmetric(
                vertical: dims.isTablet ? 15 : 10,
                horizontal: dims.isTablet ? 8 : 5,
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    '$certificatesCount',
                    style: TextStyle(
                      fontSize:
                          (dims.isTablet ? 36 : 30) * dims.textScaleFactor,
                      fontWeight: FontWeight.bold,
                      color: AppTheme.primaryColor,
                      height: 1.1,
                      letterSpacing: -1,
                    ),
                  ),
                  SizedBox(height: dims.isTablet ? 12 : 8),
                  Text(
                    'Certificates Earned',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize:
                          (dims.isTablet ? 16 : 14) * dims.textScaleFactor,
                      color: Colors.grey[700],
                      height: 1.3,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildProgressCard(BuildContext context,
      List<Course> inProgressCourses, ResponsiveDimensions dims) {
    // Limit to 2 courses for display
    final coursesToShow = inProgressCourses.take(2).toList();

    return Container(
      padding: EdgeInsets.all(dims.isTablet ? 24 : 20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Current Progress',
            style: TextStyle(
              fontSize: (dims.isTablet ? 20 : 18) * dims.textScaleFactor,
              fontWeight: FontWeight.bold,
              color: Colors.black87,
            ),
          ),
          const SizedBox(height: 20),
          ...coursesToShow.map((course) {
            final progress = _calculateCourseProgress(course);
            return Padding(
              padding: const EdgeInsets.only(bottom: 16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Expanded(
                        child: Text(
                          course.title,
                          style: TextStyle(
                            fontSize: (dims.isTablet ? 16 : 14) *
                                dims.textScaleFactor,
                            fontWeight: FontWeight.w500,
                            color: Colors.black87,
                          ),
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                      Text(
                        '${progress.toInt()}%',
                        style: TextStyle(
                          fontSize:
                              (dims.isTablet ? 16 : 14) * dims.textScaleFactor,
                          color: Colors.grey[600],
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  ClipRRect(
                    borderRadius: BorderRadius.circular(4),
                    child: LinearProgressIndicator(
                      value: progress / 100,
                      backgroundColor: Colors.grey[200],
                      valueColor: const AlwaysStoppedAnimation<Color>(
                          AppTheme.primaryColor),
                      minHeight: 8,
                    ),
                  ),
                ],
              ),
            );
          }),
        ],
      ),
    );
  }

  Widget _buildContactCard(BuildContext context, ResponsiveDimensions dims) {
    return Container(
      padding: EdgeInsets.all(dims.isTablet ? 24 : 20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Contact Information',
            style: TextStyle(
              fontSize: (dims.isTablet ? 20 : 18) * dims.textScaleFactor,
              fontWeight: FontWeight.bold,
              color: Colors.black87,
            ),
          ),
          SizedBox(height: dims.isTablet ? 20 : 16),
          _buildContactRow(
            context,
            Icons.email,
            'Email',
            _userEmail ?? 'Not available',
            dims,
            Colors.blue,
          ),
          SizedBox(height: dims.isTablet ? 20 : 16),
          _buildContactRow(
            context,
            Icons.group,
            'Business Unit',
            'Product Development',
            dims,
            Colors.orange,
          ),
          SizedBox(height: dims.isTablet ? 20 : 16),
          _buildContactRow(
            context,
            Icons.store_outlined,
            'Store',
            'San Francisco, CA',
            dims,
            Colors.green,
          ),
        ],
      ),
    );
  }

  Widget _buildContactRow(BuildContext context, IconData icon, String label,
      String value, ResponsiveDimensions dims, Color iconColor) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        Icon(
          icon,
          size: dims.isTablet ? 24 : 20,
          //color: iconColor,
            color: Colors.grey[600]
        ),
        SizedBox(width: dims.isTablet ? 16 : 12),
        Text(
          label,
          style: TextStyle(
            fontSize: (dims.isTablet ? 16 : 14) * dims.textScaleFactor,
            color: Colors.grey[600],
            fontWeight: FontWeight.w500,
          ),
        ),
        const Spacer(),
        Expanded(
          flex: 2,
          child: Text(
            value,
            textAlign: TextAlign.right,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(
              fontSize: (dims.isTablet ? 16 : 14) * dims.textScaleFactor,
              color: Colors.black87,
              fontWeight: FontWeight.w600,
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildSettingsCard(BuildContext context, ResponsiveDimensions dims) {
    return Container(
      padding: EdgeInsets.all(dims.isTablet ? 24 : 15),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
      ),
      child: Column(
        children: [
          _buildSettingsRow(
            context,
            Icons.settings,
            'Account Settings',
            AppTheme.primaryColor,
            () {
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Account Settings coming soon')),
              );
            },
            dims,
          ),
          const Divider(height: 22),
          _buildSettingsRow(
            context,
            Icons.notifications_outlined,
            'Notifications',
            AppTheme.primaryColor,
            () {
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Notifications coming soon')),
              );
            },
            dims,
          ),
          const Divider(height: 22),
          _buildSettingsRow(
            context,
            Icons.help_outline,
            'Help & Support',
            AppTheme.primaryColor,
            () {
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Help & Support coming soon')),
              );
            },
            dims,
          ),
          const Divider(height: 22),
          _buildSettingsRow(
            context,
            Icons.logout,
            'Log Out',
            Colors.red,
            () {
              _showLogoutDialog(context);
            },
            dims,
            isLogout: true,
          ),
        ],
      ),
    );
  }

  Widget _buildSettingsRow(
    BuildContext context,
    IconData icon,
    String label,
    Color iconColor,
    VoidCallback onTap,
    ResponsiveDimensions dims, {
    bool isLogout = false,
  }) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(8),
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 0),
        child: Row(
          children: [
            Container(
              width: dims.isTablet ? 40 : 36,
              height: dims.isTablet ? 40 : 36,
              decoration: BoxDecoration(
                color: iconColor.withOpacity(0.1),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Icon(
                icon,
                size: dims.isTablet ? 22 : 20,
                color: iconColor,
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Text(
                label,
                style: TextStyle(
                  fontSize: (dims.isTablet ? 18 : 16) * dims.textScaleFactor,
                  fontWeight: FontWeight.w500,
                  color: isLogout ? Colors.red : Colors.black87,
                ),
              ),
            ),
            Icon(
              Icons.chevron_right,
              color: Colors.grey[400],
              size: dims.isTablet ? 28 : 24,
            ),
          ],
        ),
      ),
    );
  }

  void _showLogoutDialog(BuildContext context) {
    final dims = AppTheme.getDimensions(context);

    showDialog(
      context: context,
      barrierColor: Colors.black54,
      builder: (context) => Dialog(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
        ),
        child: Container(
          padding: EdgeInsets.all(dims.isTablet ? 28 : 24),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(20),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              // Icon
              Container(
                width: dims.isTablet ? 80 : 64,
                height: dims.isTablet ? 80 : 64,
                decoration: BoxDecoration(
                  color: Colors.red[50],
                  shape: BoxShape.circle,
                ),
                child: Icon(
                  Icons.logout_rounded,
                  size: dims.isTablet ? 40 : 32,
                  color: Colors.red[600],
                ),
              ),
              SizedBox(height: dims.isTablet ? 24 : 20),
              // Title
              Text(
                'Log Out',
                style: TextStyle(
                  fontSize: (dims.isTablet ? 24 : 20) * dims.textScaleFactor,
                  fontWeight: FontWeight.bold,
                  color: Colors.black87,
                ),
              ),
              SizedBox(height: dims.isTablet ? 12 : 8),
              // Message
              Text(
                'Are you sure you want to log out?\nYou\'ll need to sign in again to access your account.',
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: (dims.isTablet ? 16 : 14) * dims.textScaleFactor,
                  color: Colors.grey[600],
                  height: 1.5,
                ),
              ),
              SizedBox(height: dims.isTablet ? 28 : 24),
              // Buttons
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton(
                      onPressed: () => Navigator.pop(context),
                      style: OutlinedButton.styleFrom(
                        side: BorderSide(color: Colors.grey[300]!),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                        padding: EdgeInsets.symmetric(
                          vertical: dims.isTablet ? 16 : 14,
                        ),
                      ),
                      child: Text(
                        'Cancel',
                        style: TextStyle(
                          fontSize:
                              (dims.isTablet ? 16 : 14) * dims.textScaleFactor,
                          fontWeight: FontWeight.w600,
                          color: Colors.black87,
                        ),
                      ),
                    ),
                  ),
                  SizedBox(width: dims.isTablet ? 16 : 12),
                  Expanded(
                    child: ElevatedButton(
                      onPressed: () {
                        Navigator.pop(context);
                        context.read<AuthBloc>().add(const SignOut());
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.red[600],
                        foregroundColor: Colors.white,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                        padding: EdgeInsets.symmetric(
                          vertical: dims.isTablet ? 16 : 14,
                        ),
                        elevation: 0,
                      ),
                      child: Text(
                        'Log Out',
                        style: TextStyle(
                          fontSize:
                              (dims.isTablet ? 16 : 14) * dims.textScaleFactor,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
